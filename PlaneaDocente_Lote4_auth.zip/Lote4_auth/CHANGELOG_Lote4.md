# PlaneaDocente — Lote 4: Autenticación (diagnóstico + cambios)

## ✅ Lo que está BIEN
- **Nombre real del maestro (no "Maestra Ana").** `AppSidebar` usa `user_metadata.full_name` de Google (cae a email, y solo a "Maestro" si faltaran ambos). Es el nombre real del docente. No hay nombres inventados en el código de la app.
- **Callback de OAuth** (`/auth/callback`) hace el intercambio de código y enruta según la suscripción (dashboard si activa/trial, suscripción si no). Correcto.
- **Login y Registro** usan `redirectTo: .../auth/callback` (correcto).
- **Cabeceras de seguridad + CSP** bien armadas (Stripe, Google, Supabase, Groq, etc. permitidos; `frame-ancestors 'self'`, `object-src 'none'`).
- **Sesión:** `getSession()` + `onAuthStateChange` para reaccionar a login/logout.

## 🟠 Corregido en este lote
**`src/components/auth/AuthGate.tsx`** (incluido) — el botón de Google del gate interno redirigía a `/dashboard` en vez de `/auth/callback`, **saltándose** el intercambio de código y el enrutado por suscripción (login potencialmente roto desde ese punto). Ahora va a `/auth/callback`, igual que login/registro.

> ⚠️ Tras aplicar esto, en **Supabase → Authentication → URL Configuration** y en **Google Cloud Console → Credentials → Authorized redirect URIs**, asegúrate de tener listado `https://www.planeadocente.com/auth/callback` (y el de tu dominio de Vercel si lo usas para pruebas). El de `/dashboard` ya no es necesario.

## 🟡 Pendiente / recomendaciones

**1. Verificar el trigger que crea el perfil (importante).** El callback no crea la fila en `profiles`; lo hace un trigger en `auth.users`. Corre `Lote4_perfil_trigger.sql` (paso 1) para confirmar que existe. Si no existe, ahí está el SQL para crearlo (copia el nombre real de Google a `full_name`) y un backfill para usuarios ya registrados sin perfil.

**2. Protección de rutas: hoy es solo del lado del cliente.** El `middleware.ts` solo pone cabeceras de seguridad; la auth se valida en el navegador (el dashboard espera la sesión hasta 3s). **Tus datos están protegidos** igual (RLS activo en las 29 tablas + las rutas API validan el token), así que no hay fuga; pero hay un parpadeo/espera y no es lo más robusto. La mejora "de producción" es migrar a **`@supabase/ssr`** (sesión en cookies + auth en middleware). Es un refactor mayor y más riesgoso, así que lo dejo recomendado como paso aparte, no dentro de esta tanda. Dime si quieres que lo abordemos.

**3. Archivos muertos `auth/*.sql` (raíz del repo).** Son plantillas del andamiaje "Zoer" de **otro** sistema (un "chatbox", comentarios en chino, variables `${...}`). **No tienen secretos reales** y **no los usa PlaneaDocente**. Recomiendo borrarlos del repo para evitar confusión:
   `auth/202508121418schema_auth.sql`, `auth/202508131303schema_role.sql`, `auth/202508181030schema_chatbox_rls.sql`, `auth/202508181138db_connector.sql`, `auth/202508181543schema_functions.sql`, `auth/202508221335schema_admin_user.sql`, `auth/shared_db_connector.sql`.

**4. UX menor:** la raíz `/` siempre redirige a `/landing`, incluso para usuarios ya logueados (no se les manda directo a `/dashboard`). No es un bug, solo una mejora de experiencia opcional.
