-- =====================================================================
-- PlaneaDocente — Lote 4: Perfil automático al registrarse (VERIFICAR primero)
-- =====================================================================
-- El callback de OAuth NO crea la fila en `profiles`; eso debe hacerlo un
-- TRIGGER en auth.users. Tú ya tienes una consulta guardada llamada
-- "Sync auth user inserts to profiles", así que probablemente YA existe.
--
-- >>> PRIMERO verifica. Solo crea el trigger si NO aparece nada.

-- ── 1) ¿Existe ya un trigger que sincroniza auth.users -> profiles? ──
select t.tgname            as trigger_name,
       p.proname           as funcion,
       n.nspname || '.' || c.relname as tabla
from pg_trigger t
join pg_class c   on c.oid = t.tgrelid
join pg_namespace n on n.oid = c.relnamespace
join pg_proc p    on p.oid = t.tgfoid
where c.relname = 'users' and n.nspname = 'auth' and not t.tgisinternal;

-- Si la consulta de arriba DEVUELVE una fila que inserta en profiles, NO hagas
-- nada más: ya está cubierto. Si NO devuelve nada, corre el bloque siguiente.


-- ── 2) (SOLO si no existe) Crear el trigger de forma idempotente ──
-- Inserta una fila en profiles al registrarse, copiando el nombre real de Google.
/*
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (
    new.id,
    new.email,
    coalesce(
      new.raw_user_meta_data->>'full_name',
      new.raw_user_meta_data->>'name',
      split_part(new.email, '@', 1)
    )
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
*/

-- ── 3) Backfill: crear perfil para usuarios que ya existen pero no tienen fila ──
-- (Seguro de correr; solo agrega los que falten.)
/*
insert into public.profiles (id, email, full_name)
select u.id, u.email,
       coalesce(u.raw_user_meta_data->>'full_name', u.raw_user_meta_data->>'name', split_part(u.email,'@',1))
from auth.users u
left join public.profiles p on p.id = u.id
where p.id is null
on conflict (id) do nothing;
*/
