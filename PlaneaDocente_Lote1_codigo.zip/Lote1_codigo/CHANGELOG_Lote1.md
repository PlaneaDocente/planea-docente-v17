# PlaneaDocente — Lote 1: Código y estructura (cambios aplicados)

Estos cambios corrigen el código para que apunte a tu **base real** y eliminan datos falsos y rutas muertas/inseguras. Aplica los archivos de la carpeta `Lote1_codigo/` sobre tu repo (respetan la ruta), y borra los archivos de la sección "ELIMINAR".

---

## 1) Archivos MODIFICADOS (incluidos en este paquete)

### `src/components/planea/SuscripcionSection.tsx` — historial de pagos
- **Antes:** llamaba a `/api/payments?user_id=...` (ruta insegura que consultaba la tabla inexistente `payments`, ordenaba por `created_at` inexistente y leía `subscription.status` en vez de `estado`). Además esperaba `{ success, data: [] }`, pero esa ruta devolvía un **objeto**, no un array → el historial nunca se mostraba.
- **Ahora:** llama a `/api/payment-history?userId=...` (ruta **segura**: valida el token y que el `userId` sea el del propio usuario). Maneja la respuesta como array. Se corrigió el render para usar `p.created_at` (la columna real) en vez de `p.fecha`, y `p.moneda` se volvió defensivo ante `null`.
- ⚠️ **Verificar:** que la tabla `payment_history` tenga la columna `created_at`. Si tu columna de fecha tiene otro nombre, ajusta el `.order("created_at")` de `src/app/api/payment-history/route.ts` y el `p.created_at` del render.

### `src/components/planea/DashboardSection.tsx` — calendario
- **Antes:** el calendario del dashboard se llenaba con `mockCalendario` (eventos inventados: "Examen Bimestral", "Día del Maestro", etc.).
- **Ahora:** `calendarEvents` queda vacío (estado honesto) con un `TODO` para conectarlo a una tabla real de eventos/recordatorios cuando exista. Se eliminó el import de `mock-data`.

### `src/components/landing/LandingPageClient.tsx` — landing pública (/landing)
- **Antes:** testimonios inventados ("Maestra Ana García", "Maestro Carlos López", "Directora María Soto") y stats infladas ("5,000+ Maestros activos", "150,000+ Planeaciones", "98% Satisfacción").
- **Ahora:** testimonios vacíos + la sección se oculta sola hasta que agregues reseñas reales. Stats reemplazadas por datos verificables del producto (alineación NEM, IA, web, prueba de 15 días).

### `src/components/landing/LandingPage.tsx` — landing dentro de la app (MainLayout)
- Mismo problema (era un **segundo** componente de landing con otras cifras y testimonios falsos: "Ana Martínez", "Carlos Rodríguez", "Laura Sánchez"). Corregido igual.
- 📌 Nota: tienes **dos** componentes de landing. No es un error en sí, pero conviene unificarlos a futuro para no mantener copias.

---

## 2) Archivos a ELIMINAR de tu repo (ya borrados en mi copia)

- `src/app/api/payments/route.ts` → ruta **insegura** (anon key sin validar token, IDOR potencial) y rota contra el esquema real. Reemplazada por `/api/payment-history`.
- `src/app/next_api/stripe/customer-portal/route.ts` → **duplicado muerto**. El frontend usa `src/app/api/stripe/customer-portal`.
- `src/data/mock-data.ts` → datos falsos; ya nadie lo importa tras el cambio del dashboard.
- `build-error.log` → log residual de un error ya corregido.

---

## 3) Seguridad
- ✅ No se encontraron claves secretas hardcodeadas en el código.
- ✅ No hay archivos `.env` dentro del ZIP.
- ⏳ Pendiente: confirmar que esas claves tampoco estén en el historial de Git de GitHub.

---

## 4) Pendiente (no aplicado, requiere acción tuya)
- **`src/integrations/supabase/types.ts`** está desactualizado (9 tablas con nombres viejos: `users`, `payments`, `comunicados`). **No rompe el build** porque el cliente no está tipado con `Database`. Regéneralo desde tu base real:
  ```bash
  npx supabase login
  npx supabase gen types typescript --project-id TU_PROJECT_ID --schema public > src/integrations/supabase/types.ts
  ```
- **`/api/admin/stripe-config`**: el botón de "configurar Stripe desde la app" llama a un endpoint que no existe (no crashea, muestra un aviso). Decidir: crear el endpoint o quitar el botón. Lo veremos en el Lote de Stripe.

---

## 5) Cómo validar en local
```bash
npm install
npm run lint        # debe pasar
npx tsc --noEmit    # typecheck, debe pasar
npm run build       # requiere .env.local con las variables (ver Lote de Vercel)
```
