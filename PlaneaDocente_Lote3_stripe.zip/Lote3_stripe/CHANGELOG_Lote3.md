# PlaneaDocente — Lote 3: Stripe (cambios aplicados)

Aplica los archivos de `Lote3_stripe/` sobre tu repo (respetan la ruta) y corre el SQL opcional.

## Archivos incluidos

### `src/app/next_api/stripe/webhook/route.ts` (REEMPLAZA el actual)
Correcciones:
1. **Ahora SÍ escribe `payment_history`.** Antes ninguna parte del código insertaba ahí, así que el historial de pagos siempre salía vacío. Ahora `invoice.payment_succeeded` (y `invoice.payment_failed`) registran el pago, resolviendo `user_id` y `subscription_id` reales, con **idempotencia** por `stripe_invoice_id` y omitiendo facturas de $0 (arranque de prueba).
2. **Arreglado el nombre de columnas de price-id**: ahora busca el plan por `stripe_price_id` / `stripe_price_id_anual` (los reales), no por `stripe_price_id_monthly` / `_annual`. Así los cambios de plan sincronizan el `plan_id`.
3. **Upsert de `subscriptions` validado** contra columnas reales: `cancelar_al_periodo_fin` existe y `fecha_inicio` tiene default; se setea `updated_at` en cada cambio. Fechas en ISO completo (la columna es `timestamptz`).
4. Al cancelar/expirar se limpia también `plan_actual` en `profiles`.

### `src/app/api/stripe/customer-portal/route.ts` (REEMPLAZA el actual)
- **Endurecido:** ya no confía en el `customerId` que mandaba el navegador (riesgo de abrir el portal de otro cliente). Ahora autentica al usuario por su token y toma `stripe_customer_id` de **su propio** perfil en el servidor.

### `src/components/planea/SuscripcionSection.tsx` (REEMPLAZA el del Lote 1)
- `handleOpenPortal` ahora manda el `Authorization: Bearer <token>` y ya no envía `customerId`.
- (Este archivo ya incluye los cambios del Lote 1 sobre el historial de pagos.)

## SQL opcional: `Lote3_robustez_webhook.sql`
Crea el índice único en `subscriptions.stripe_subscription_id` (para que el upsert del webhook sea 100% confiable) y un índice en `payment_history.stripe_invoice_id`. Idempotente.

---

## ⚠️ Acción de configuración pendiente (no es código)

**El cobro ANUAL no está configurado.** Los tres planes tienen `stripe_price_id_anual = NULL`. Si en la UI un usuario elige "anual", no hay `price_` que mandar → el checkout falla. Opciones:
1. Crear los precios anuales en el Dashboard de Stripe y pegarlos en `subscription_plans.stripe_price_id_anual`, o
2. Ocultar la opción anual hasta tenerlos.

Price IDs **mensuales** actuales (verificados):
- básico → `price_1TZHEcFCwyyS7eA2iv9xSmXB`
- profesional → `price_1TZHHSFCwyyS7eA2P8z6EYGh`
- institucional → `price_1TZHJNFCwyyS7eA29DdDPyXR`

## Verificación tras desplegar
1. En Stripe → Developers → Webhooks, confirma que el endpoint apunta a `https://www.planeadocente.com/next_api/stripe/webhook` y que escucha: `checkout.session.completed`, `invoice.payment_succeeded`, `invoice.payment_failed`, `customer.subscription.updated`, `customer.subscription.deleted`.
2. Haz un pago de prueba (modo test) y verifica: se crea fila en `subscriptions` (estado `trialing`), `profiles.is_pro = true`, y al primer cobro real aparece fila en `payment_history`.
3. Revisa que el botón "Administrar suscripción" abra el portal (ahora requiere sesión válida).
