-- =====================================================================
-- PlaneaDocente — Lote 3: Robustez para el webhook de Stripe (OPCIONAL)
-- =====================================================================
-- El webhook hace upsert sobre subscriptions con onConflict = "stripe_subscription_id".
-- Para que ese upsert sea 100% confiable, esa columna debe tener un índice ÚNICO.
-- (Tus suscripciones actuales ya parecen guardarse, así que probablemente ya existe;
--  este comando es idempotente y no hace nada si ya está.)
--
-- Si este CREATE falla por valores duplicados, primero deduplica y vuelve a correrlo.

create unique index if not exists uq_subscriptions_stripe_sub_id
  on public.subscriptions(stripe_subscription_id)
  where stripe_subscription_id is not null;

-- Acelera la búsqueda idempotente de pagos por factura:
create index if not exists idx_payment_history_invoice
  on public.payment_history(stripe_invoice_id);

-- Verificación:
-- select indexname, indexdef from pg_indexes
-- where schemaname='public' and tablename in ('subscriptions','payment_history');
